import time,copy
import argparse
import math
import torch
import torch.nn as nn
from rouge import Rouge
from transformers import AutoTokenizer,AutoModelForSeq2SeqLM,BertForSequenceClassification,BertTokenizer
from transformers import AdamW
from torch.optim import *
import numpy as np
from data_loader_dataset import data_loader
import os 
from tqdm import tqdm
from bert_relevance_check import bert_relevance_model
class Train(object):

    def __init__(self, config):
        self.config = config  
        
        seed = self.config.seed
        torch.manual_seed(seed)            
        torch.cuda.manual_seed(seed)      
        torch.cuda.manual_seed_all(seed)         
        

        self.tokenizer = AutoTokenizer.from_pretrained(self.config.pretrained_tokenizer)
            
        self.log = open('log.txt','w')
        
        self.dataloader=data_loader('train', self.config, self.tokenizer,model='doc2query', data_augmentation=self.config.data_augmentation)

        self.relevance_model=bert_relevance_model(load_path=self.config.relevance_model)
        self.relevance_model.cuda()   

        if self.config.mid_start == 0:
            self.generator_raw = AutoModelForSeq2SeqLM.from_pretrained(self.config.pretrained_model)
        else:    
            x=torch.load('save_model/'+config.load_model,map_location='cpu')
            self.generator_raw = x['generator']  
            self.generator_raw.cuda()


        if self.config.multi_gpu==1:
            gpus=[int(gpu) for gpu in self.config.multi_device.split(',')]
            self.generator = nn.DataParallel(self.generator_raw,device_ids=gpus, output_device=gpus[0])
            self.generator.cuda()
        else:
            self.generator=self.generator_raw
            self.generator.cuda()  


        param_optimizer = list(self.generator.named_parameters())
        optimizer_grouped_parameters = [
            {'params': [p for n, p in param_optimizer], 'weight_decay': 0.01}]

        self.optimizer = AdamW(optimizer_grouped_parameters, lr=config.lr)        


        
    def save_model(self, running_avg_loss,loss_list,rouge1,rouge2,loss_text=''):

        state = {
            'iter': self.dataloader.count/self.config.true_batch_size*self.config.batch_size,
            'ecop': self.dataloader.epoch,
            'generator':self.generator.module,
            'current_loss': running_avg_loss,
            'loss_list': loss_list,
            'rouge1':rouge1,
            'rouge2':rouge2,
            'config':self.config
        }
        try:
            model_save_path = self.config.save_path+str(self.dataloader.count/self.config.true_batch_size*self.config.batch_size)+'_iter_'+str(self.dataloader.epoch) +'_epoch__rouge_'+str(rouge1)[:4]+'_'+str(rouge2)[:4]+'__loss_'+str(running_avg_loss)[:4]+loss_text
            torch.save(state, model_save_path)
        except:
            print('can not save the model!!!')
        
        
        
    def train_one_batch(self):


        batch_source_id,batch_source_id_mask,batch_target_id,batch_target_id_mask,batch_label,batch_source,batch_target,batch_other_data= \
        self.dataloader.load_data()


        generator_outputs = self.generator(input_ids=batch_source_id,
                                           attention_mask=batch_source_id_mask,
                                           labels=batch_target_id)
        seq_loss = generator_outputs.loss
        seq_loss.mean().backward()
        return seq_loss.mean().item(), 1

    
 
    def train_iter(self):
        loss_list=[]

        count=0
        self.generator.train()
        for i in range(self.config.max_epoch*self.config.train_set_len):
            count=count+1
            time_start=time.time()
            
            success=0
            for j in range(int(self.config.true_batch_size/self.config.batch_size)):     

                loss,tag = self.train_one_batch()
           
                if tag == 1:
                    loss_list.append(loss)
                    success=success+1
                    
                if tag == 0:
                    print('one mini batch fail')                            
                    continue
                
            if success == int(self.config.true_batch_size/self.config.batch_size):                
                self.optimizer.step()                         
                self.optimizer.zero_grad()

                if self.config.use_lr_decay == 1:
                    if count%self.config.lr_decay_step == 0:
                        self.scheduler.step()         
            else:
                print('jump one batch')     
                
            time_end=time.time()                
            
            def loss_record(loss_list,window):
                recent_list=loss_list[max(0,len(loss_list)-window*int(self.config.true_batch_size/self.config.batch_size)):]
                return str(np.mean(recent_list))[:4]
            
            if count % self.config.checkfreq == 0:       
                record=str(count)+' iter '+str(self.dataloader.epoch) +' epoch avg_loss:'+loss_record(loss_list,1000)
                    
                record+=' -- use time:'+str(time_end-time_start)[:5]
                print(record)
                
                
            if count % self.config.savefreq == 0 and count > self.config.savefreq-1000 and count > self.config.startfreq:     
                recent_loss=loss_list[max(0,len(loss_list)-1000*int(self.config.true_batch_size/self.config.batch_size)):]
                avg_loss=sum(recent_loss)/len(recent_loss)
                 
                print('start val')
                rouge1,rouge2,expanded_text=self.do_val(11118)  
                
                self.save_model(avg_loss,loss_list,rouge1,rouge2,expanded_text) 
                self.generator.module.train()         
                
                
    def do_val(self, val_num):

        self.raw_rouge=Rouge()
        self.generator.module.eval()

        data_loader_val=data_loader('val', self.config, self.tokenizer, model='inference')
     
        r1=[]
        r2=[]
        
        sample_number=5
        
        relevance=[]
                
        for i in tqdm(range(int(val_num/16)),desc='Validation'):     
            
            #try:
            
                batch_source_id,batch_source_id_mask,batch_target_id,batch_target_id_mask,batch_label,batch_source,batch_target,batch_other_data = \
                data_loader_val.load_data()

                with torch.no_grad():           
    
                    outputs_beam = self.generator.module.generate(input_ids=batch_source_id,
                                                       attention_mask=batch_source_id_mask,
                                                         num_return_sequences=sample_number, 
                                                         num_beam_groups=sample_number, 
                                                         diversity_penalty=0.6, 
                                                         num_beams=20,
                                                         max_length=10,
                                                         no_repeat_ngram_size=2,
                                                         early_stopping=True)       
                    
                    decoded_pred = self.tokenizer.batch_decode(outputs_beam, skip_special_tokens=True)  
                    
                    '''
                    outputs = self.generator.module.generate(
                                        input_ids=batch_source_id,
                                        attention_mask=batch_source_id_mask,
                                        max_length=20,
                                        do_sample=True,
                                        top_p=0.95,
                                        top_k=15, 
                                        temperature=2.0,
                                        num_return_sequences=50)
                    '''
                

                    source_list=[]
                    for j in batch_source:
                        source_list+=[j]*sample_number
                        
                    relevance_score,relevance_list = self.relevance_evaluator(decoded_pred, source_list, self.relevance_model)
                    relevance.append(relevance_score)

                for j in range(16):                                  

                    pred=' '.join(decoded_pred[j*sample_number:j*sample_number+sample_number])
                    gold=' '.join(batch_other_data[1][j])
                    

                    
                    pred=' '.join(pred)    
                    gold=' '.join(gold)
                    
                    scores = self.raw_rouge.get_scores(pred, gold)
                    
                    r1.append(scores[0]['rouge-1']['f'])
                    r2.append(scores[0]['rouge-2']['f'])        
        

                    
                if data_loader_val.epoch == 2:
                    break
                
                
            #except:
                #print('one sample fail during the evaluation')
                #continue            
                    
        if len(r1) != 0 and len(r2) != 0:
            #expanded_text='_repeat_'+str(np.mean(no_repeat))[:4]+'_pair_sim_'+str(np.mean(pair_wise_sim))[:4]+'_abs_'+str((np.mean(abstract_2)+np.mean(abstract_3))/2)[:4]+'_rel_'+str(np.mean(relevance))[:4]
            expanded_text=''
            return np.mean(r1),np.mean(r2),expanded_text
        else:
            return 0,0,''             


                
    def do_test(self, val_num=11118):

        self.raw_rouge=Rouge()
        self.generator.module.eval()

        data_loader_val=data_loader('test', self.config, self.tokenizer, model='inference')
     
        r1=[]
        r2=[]
        
        sample_number=5
        
        relevance=[]
                
        for i in tqdm(range(int(val_num/16)),desc='testing'):     

                batch_source_id,batch_source_id_mask,batch_target_id,batch_target_id_mask,batch_label,batch_source,batch_target,batch_other_data = \
                data_loader_val.load_data()

                with torch.no_grad():           
    
                    outputs_beam = self.generator.module.generate(input_ids=batch_source_id,
                                                       attention_mask=batch_source_id_mask,
                                                         num_return_sequences=sample_number, 
                                                         num_beam_groups=sample_number, 
                                                         diversity_penalty=0.6, 
                                                         num_beams=20,
                                                         max_length=10,
                                                         no_repeat_ngram_size=2,
                                                         early_stopping=True)       
                    
                    decoded_pred = self.tokenizer.batch_decode(outputs_beam, skip_special_tokens=True)  
                    
                    '''
                    outputs = self.generator.module.generate(
                                        input_ids=batch_source_id,
                                        attention_mask=batch_source_id_mask,
                                        max_length=20,
                                        do_sample=True,
                                        top_p=0.95,
                                        top_k=15, 
                                        temperature=2.0,
                                        num_return_sequences=50)
                    '''
                

                    source_list=[]
                    for j in batch_source:
                        source_list+=[j]*sample_number
                        
                    relevance_score,relevance_list = self.relevance_evaluator(decoded_pred, source_list, self.relevance_model)
                    relevance+=relevance_list

                for j in range(16):                                  

                    pred=' '.join(decoded_pred[j*sample_number:j*sample_number+sample_number])
                    gold=' '.join(batch_other_data[1][j])
                    

                    
                    pred=' '.join(pred)    
                    gold=' '.join(gold)
                    
                    scores = self.raw_rouge.get_scores(pred, gold)
                    
                    r1.append(scores[0]['rouge-1']['f'])
                    r2.append(scores[0]['rouge-2']['f'])        
        
                    
                if data_loader_val.epoch == 2:
                    break
                

                    
        if len(r1) != 0 and len(r2) != 0:
            expanded_text=str(np.mean(relevance))
            print(np.mean(r1),np.mean(r2),expanded_text)
            return np.mean(r1),np.mean(r2),expanded_text
        else:
            return 0,0,''        


    def diverse_pairwise_n_gram(self, pred_list):
        pred_list=[' '.join(list(pred)) for pred in pred_list]
        sample_number=len(pred_list)
        r1=[]
        r2=[]
        for i in range(sample_number)[:-1]:
            for j in range(sample_number)[i+1:]:     
                try:
                    scores = self.raw_rouge.get_scores(pred_list[i], pred_list[j])
                    r1.append(scores[0]['rouge-1']['f'])
                    r2.append(scores[0]['rouge-2']['f'])       
                except:
                    r1.append(0)
                    r2.append(0)                       
        scale=sample_number*(sample_number-1)/2
        
        return np.sum(r1)/scale,np.sum(r2)/scale
    

    def diverse_distinct_n(self, pred_list, n):
        n_gram_all=[]
        for i in pred_list:
            n_gram_all+=self.create_ngram_list(i,n)
        n_gram_unq=list(set(n_gram_all))      
        return len(n_gram_unq)/len(n_gram_all)    


    def diverse_abstract_n(self, pred_list, source,n):
        n_gram_all=[]
        for i in pred_list:
            n_gram_all+=self.create_ngram_list(i,n)
        n_gram_source=self.create_ngram_list(source, n)
        count_abs=0
        for i in pred_list:
            n_gram_one_query=self.create_ngram_list(i,n)  
            for one_n_gram in n_gram_one_query:
                if one_n_gram not in n_gram_source:
                    count_abs+=1

        return count_abs/len(n_gram_all)
    

    def create_ngram_list(self,input_list, ngram_num):
        ngram_list = []
        if len(input_list) <= ngram_num:
            ngram_list.append(input_list)
        else:
            for tmp in zip(*[input_list[i:] for i in range(ngram_num)]):
                tmp = "".join(tmp)
                ngram_list.append(tmp)
        return ngram_list

    def top_coverage(self,input_list,top_list):
       count=[]
       for i in input_list:
           if i in top_list:
               count.append(1)
           else:
               count.append(0)
       
       return sum(count)/len(input_list),count
      
   
    def relevance_evaluator(self, input_list,source, model):
       scores = model(input_list,source)
       count=0
       for i in scores:
           if i >0.65:
               count+=1
       return count/len(scores),scores


    

        


def argLoader():

    parser = argparse.ArgumentParser()
    
    #device
    
    parser.add_argument('--device', type=int, default=0)    
    
    parser.add_argument('--multi_gpu', type=int, default=1)        

    parser.add_argument('--multi_device', type=str, default='0,1')       
    # Do What
    
    parser.add_argument('--do_train', action='store_true', help="Whether to run training")

    parser.add_argument('--do_test', action='store_true', help="Whether to run test")
    
    parser.add_argument('--pretrain', type=int, default=0) 
    
    parser.add_argument('--data_path', type=str, default='')
    
    parser.add_argument('--seed', type=int, default=10)  
    
    parser.add_argument('--data_augmentation', type=int, default=0)      
    
    parser.add_argument('--pretrained_model', type=str, default='doc2query/msmarco-chinese-mt5-base-v1')  
    
    parser.add_argument('--pretrained_tokenizer', type=str, default='doc2query/msmarco-chinese-mt5-base-v1')  

    parser.add_argument('--bos_token_id', type=int, default=0) 
    
    parser.add_argument('--pad_token_id', type=int, default=0) 
    
    parser.add_argument('--eos_token_id', type=int, default=1)
    #Preprocess Setting
    parser.add_argument('--max_summary', type=int, default=20)

    parser.add_argument('--max_article', type=int, default=300)    
    
    #Model Setting
    parser.add_argument('--hidden_dim', type=int, default=768)

    parser.add_argument('--emb_dim', type=int, default=768)
    
    parser.add_argument('--vocab_size', type=int, default=50264)      

    parser.add_argument('--lr', type=float, default=5e-5)     
    
    parser.add_argument('--eps', type=float, default=1e-10)
    
    parser.add_argument('--prefix_dropout', type=float, default=0)    
        
    parser.add_argument('--batch_size', type=int, default=64)  

    parser.add_argument('--true_batch_size', type=int, default=128)  

    parser.add_argument('--buffer_size', type=int, default=8192)      
    
    parser.add_argument('--scale_embedding', type=int, default=0)  
    
    #lr setting

    parser.add_argument('--use_lr_decay', type=int, default=0)  
    
    parser.add_argument('--lr_decay_step', type=int, default=10000)  
    
    parser.add_argument('--lr_decay', type=float, default=1)  

    # Testing setting
    parser.add_argument('--beam_size', type=int, default=2)
    
    parser.add_argument('--max_dec_steps', type=int, default=15)
    
    parser.add_argument('--min_dec_steps', type=int, default=2)
    
    parser.add_argument('--test_model', type=str, default='')   
    
    parser.add_argument('--load_model', type=str, default='')  

    parser.add_argument('--save_path', type=str, default='')  
    
    parser.add_argument('--relevance_model', type=str, default='') 
    
    parser.add_argument('--mid_start', type=int, default=0)
   
    # Checkpoint Setting
    parser.add_argument('--max_epoch', type=int, default=40)
    
    parser.add_argument('--train_set_len', type=int, default=190000)
    
    parser.add_argument('--savefreq', type=int, default=1200)

    parser.add_argument('--checkfreq', type=int, default=1)    

    parser.add_argument('--startfreq', type=int, default=1)        
    
    args = parser.parse_args()
    
    return args





def main():
    args = argLoader()
    
    if args.multi_gpu==1:
        torch.cuda.set_device(args.device)
        os.environ['CUDA_VISIBLE_DEVICES'] = args.multi_device
    else:
        torch.cuda.set_device(args.device)

    print('CUDA', torch.cuda.current_device())
    
    test_model=[]
        
    if args.do_train == 1:
        x=Train(args)
        x.train_iter()
    if args.do_test==1:
        for i in test_model:
            print('start testing the model:'+i)
            args.mid_start = 1
            args.load_model = i
            
            x=Train(args)
            r1,r2,rele=x.do_test()
            print('============================')

main()
        