import glob
import random
import struct
import json
import re
import torch
import csv
import argparse
from transformers import BartTokenizer
import nltk
from nltk import word_tokenize
import glob 
#nltk.download('punkt')

class data_loader():

    def __init__(self, part, config, tokenizer, model='doc2query', data_augmentation=0):

        super(data_loader,self).__init__()  
      
        self.part=part
        self.tokenizer=tokenizer
        self.config=config
        
        random.seed(self.config.seed)
        
        self.count=0
        self.epoch=0
        self.model=model
        self.data_augmentation=data_augmentation
        
        self.max_epoch=config.max_epoch
        self.buffer_size=config.buffer_size
        self.batch_size=config.batch_size
        self.true_batch_size=config.true_batch_size
        self.max_article=config.max_article
        self.max_summary=config.max_summary
        
        if self.model == 'doc2query_with_contrast':
            self.buffer_size=self.batch_size
        
    
        if self.model == 'inference' and (self.part == 'val' or self.part == 'test'):
            
            self.max_epoch=2
            self.buffer_size=16
            self.batch_size=16
            self.true_batch_size=16
            self.max_article=config.max_article
            self.max_summary=config.max_summary            

        
 
        self.source_path = self.config.data_path
        
        if self.part == 'train':
            self.source_path+='train*'
        if self.part == 'val':
            self.source_path+='val*'
        if self.part == 'test':
            self.source_path+='test*'

        self.data_generator=self.next_data() 
        
        self.batch_generator=self.next_batch()         

       
    def load_multiple_json(self, path):
        path_list=glob.glob(path)
        data_all=[]
        for i in path_list:
            with open(i,'r') as load_f:
                data = json.load(load_f)  
                data_all+=data.values()
        return data_all


    def next_data(self):
        buffer=[]
        for epoch in range(self.max_epoch):
            self.epoch=self.epoch+1
            
            data = self.load_multiple_json(self.source_path)                   
 
            if self.part == 'train':
                random.shuffle(data)
                
            print('the data number for one epoch is ', len(data))
                
            for data_point in data:
                
                topic=data_point["topic"]
                doc=data_point["doc"]
                reference_query_high_rele=data_point["query_high_rele"]
                reference_query_low_rele=data_point["query_low_rele"]
                
                query_high_rele=reference_query_high_rele[:10]
                query_low_rele =reference_query_low_rele[:10]
                
                
                if len(query_high_rele) == 0 or len(query_low_rele) == 0:
                    continue

                
                if self.data_augmentation == 1 and self.part == 'train':
                    query_high_rele=reference_query_high_rele[:1]
                    query_low_rele=reference_query_high_rele[:1]
                    
                
                if self.model == 'doc2query' or self.model == 'inference':
                    source=doc
                    target=query_high_rele[random.randint(0, len(query_high_rele)-1)]
                    source_id=self.tokenizer.encode(source)[:self.config.max_article]
                    target_id=self.tokenizer.encode(target)[:self.config.max_summary]
                    label=-1
                    
                    buffer.append((target_id,source_id,label,target,source,topic,reference_query_high_rele,reference_query_low_rele,[],[]))  
                    
                if self.model == 'doc2query_with_contrast':
                    source=doc
                    target=query_high_rele[random.randint(0, len(query_high_rele)-1)]
                    source_id=self.tokenizer.encode(source)[:self.config.max_article]
                    target_id=self.tokenizer.encode(target)[:self.config.max_summary]
                    label=-1
                    
                    buffer.append((target_id,source_id,label,target,source,topic,reference_query_high_rele,reference_query_low_rele,[],[]))  
                    
                    source=doc
                    target=query_low_rele[random.randint(0, len(query_low_rele)-1)]
                    source_id=self.tokenizer.encode(source)[:self.config.max_article]
                    target_id=self.tokenizer.encode(target)[:self.config.max_summary]
                    label=-1
                    
                    buffer.append((target_id,source_id,label,target,source,topic,reference_query_high_rele,reference_query_low_rele,[],[]))  

                    
                if self.model == 'relevance':
                    source=doc
                    target=query_high_rele[random.randint(0, len(query_high_rele)-1)]
                    source_id=(self.tokenizer.encode(target)+self.tokenizer.encode(doc))[:self.config.max_article]
                    target_id=[]
                    label=0
                    
                    buffer.append((target_id,source_id,label,target,source,topic,reference_query_high_rele,reference_query_low_rele,[],[]))  

                    source=doc
                    target=query_low_rele[random.randint(0, len(query_low_rele)-1)]
                    source_id=(self.tokenizer.encode(target)+self.tokenizer.encode(doc))[:self.config.max_article]
                    target_id=[]
                    label=1
                    
                    buffer.append((target_id,source_id,label,target,source,topic,reference_query_high_rele,reference_query_low_rele,[],[]))
                    
                    
                if self.model == 'relevance_check':
                    
                    source=doc
                    for i in reference_query_high_rele:
                        target=i
                        source_id=(self.tokenizer.encode(target)+self.tokenizer.encode(doc))[:self.config.max_article]                        
                        target_id=[]
                        label=0
                    
                        buffer.append((target_id,source_id,label,target,source,topic,reference_query_high_rele,reference_query_low_rele,[],[]))  

                    source=doc
                    for i in reference_query_low_rele:
                        target=i
                        source_id=(self.tokenizer.encode(target)+self.tokenizer.encode(doc))[:self.config.max_article]                        
                        target_id=[]
                        label=1
                    
                        buffer.append((target_id,source_id,label,target,source,topic,reference_query_high_rele,reference_query_low_rele,[],[])) 
                        
                        
                        
                if len(buffer) >= self.buffer_size:
                    yield buffer
                    buffer=[]
                        
        print ("data_generator completed reading all datafiles for all epoches. No more data.")                       
        return 0
    



    
    
    
    def next_batch(self):
        while(True):
            buffer = self.data_generator.__next__()
            buffer.sort(key=self.get_sort)
            
            for batch_idx in range(int(len(buffer)/self.batch_size)):
                                   
                batch_data=buffer[batch_idx*self.batch_size:(batch_idx+1)*self.batch_size]
                
                batch_source_id=[]
                batch_target_id=[]
                batch_label=[]
                batch_source=[]
                batch_target=[]
                batch_topic=[]
                batch_reference_query_high_rele=[]
                batch_reference_query_low_rele=[]
                batch_generated_query_high_rele=[]
                batch_generated_query_low_rele=[]                
                
                
                for data_point in batch_data:
                
                    target_id,source_id,label,target,source,topic,reference_query_high_rele,reference_query_low_rele,generated_query_high_rele,generated_query_low_rele=data_point
                    batch_source_id.append(source_id)
                    batch_target_id.append(target_id)
                    batch_label.append(label)
                    batch_source.append(source)
                    batch_target.append(target)    
                    batch_topic.append(topic) 
                    batch_reference_query_high_rele.append(reference_query_high_rele) 
                    batch_reference_query_low_rele.append(reference_query_low_rele) 
                    batch_generated_query_high_rele.append(generated_query_high_rele) 
                    batch_generated_query_low_rele.append(generated_query_low_rele)          
            

                batch_source_id,batch_source_id_mask=self.pad_with_mask(batch_source_id, pad_id=self.config.pad_token_id)
                batch_source_id=torch.tensor(batch_source_id)
                batch_source_id_mask=torch.tensor(batch_source_id_mask) 
                
                batch_target_id,batch_target_id_mask=self.pad_with_mask(batch_target_id, pad_id=self.config.pad_token_id)
                batch_target_id=torch.tensor(batch_target_id)
                batch_target_id_mask=torch.tensor(batch_target_id_mask)       

                                   
                
                batch_source_id=batch_source_id.cuda()
                batch_source_id_mask=batch_source_id_mask.cuda()
                batch_target_id=batch_target_id.cuda()
                batch_target_id_mask=batch_target_id_mask.cuda()
                batch_label=torch.tensor(batch_label).cuda()
                
                batch_other_data=[batch_topic,batch_reference_query_high_rele,batch_reference_query_low_rele,batch_generated_query_high_rele,batch_generated_query_low_rele]

                yield batch_source_id,batch_source_id_mask,batch_target_id,batch_target_id_mask,batch_label,batch_source,batch_target,batch_other_data
                

    def load_data(self):
        self.count=self.count+1
        return self.batch_generator.__next__()
                    
            
    def get_sort(self, x):
        return len(x[1])


    def pad_with_mask(self, data, pad_id=0, width=-1):
        if (width == -1):
            width = max(len(d) for d in data)
            
        rtn_data = [d + [pad_id] * (width - len(d)) for d in data]
        
        pad_mask = [[1] * len(d) + [0] * (width - len(d)) for d in data]
        return rtn_data,pad_mask 