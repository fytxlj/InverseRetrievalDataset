import time,copy
import argparse
import math
import torch
import torch.nn as nn
from rouge import Rouge
from transformers import AutoTokenizer,AutoModelForSequenceClassification
from transformers import AdamW
from torch.optim import *
import numpy as np
from data_loader_dataset import data_loader
import os 
from tqdm import tqdm
class Train(object):

    def __init__(self, config):
        self.config = config  
        
        seed = self.config.seed
        torch.manual_seed(seed)            
        torch.cuda.manual_seed(seed)       
        torch.cuda.manual_seed_all(seed)         
        

        self.tokenizer = AutoTokenizer.from_pretrained(self.config.pretrained_tokenizer)
            
        self.log = open('log.txt','w')
        
        self.dataloader=data_loader('train', self.config, self.tokenizer,model='relevance', data_augmentation=self.config.data_augmentation)


        if self.config.mid_start == 0:
            self.generator_raw = AutoModelForSequenceClassification.from_pretrained(self.config.pretrained_model, num_labels=2)
        else:    
            x=torch.load('save_model/'+config.load_model,map_location='cpu')
            self.generator_raw = x['generator']  
            self.generator_raw.cuda()


        if self.config.multi_gpu==1:
            gpus=[int(gpu) for gpu in self.config.multi_device.split(',')]
            self.generator = nn.DataParallel(self.generator_raw,device_ids=gpus, output_device=gpus[0])
            self.generator.cuda()
        else:
            self.generator=self.generator_raw
            self.generator.cuda()  


        param_optimizer = list(self.generator.named_parameters())
        optimizer_grouped_parameters = [
            {'params': [p for n, p in param_optimizer], 'weight_decay': 0.01}]

        self.optimizer = AdamW(optimizer_grouped_parameters, lr=config.lr)        


        
    def save_model(self, running_avg_loss,loss_list,rouge1,rouge2,loss_text=''):

        state = {
            'iter': self.dataloader.count/self.config.true_batch_size*self.config.batch_size,
            'ecop': self.dataloader.epoch,
            'generator':self.generator.module,
            'current_loss': running_avg_loss,
            'loss_list': loss_list,
            'rouge1':rouge1,
            'rouge2':rouge2,
            'config':self.config
        }
        try:
            model_save_path = self.config.save_path+str(self.dataloader.count/self.config.true_batch_size*self.config.batch_size)+'_iter_'+str(self.dataloader.epoch) +'_epoch__rouge_'+str(rouge1)[:4]+'_'+str(rouge2)[:4]+'__loss_'+str(running_avg_loss)[:4]+loss_text
            torch.save(state, model_save_path)
        except:
            print('can not save the model!!!')
        
        
        
    def train_one_batch(self):


        batch_source_id,batch_source_id_mask,batch_target_id,batch_target_id_mask,batch_label,batch_source,batch_target,batch_other_data= \
        self.dataloader.load_data()

        classifier_outputs = self.generator(input_ids=batch_source_id,
                                           attention_mask=batch_source_id_mask,
                                           labels=batch_label)
        
        
        
        loss = classifier_outputs.loss
        loss.mean().backward()
        return loss.mean().item(), 1

    
 
    def train_iter(self):
        loss_list=[]

        count=0
        self.generator.train()
        for i in range(self.config.max_epoch*self.config.train_set_len):
            count=count+1
            time_start=time.time()
            
            success=0
            for j in range(int(self.config.true_batch_size/self.config.batch_size)):     

                loss,tag = self.train_one_batch()
           
                if tag == 1:
                    loss_list.append(loss)
                    success=success+1
                    
                if tag == 0:
                    print('one mini batch fail')                            
                    continue
                
            if success == int(self.config.true_batch_size/self.config.batch_size):                
                self.optimizer.step()                         
                self.optimizer.zero_grad()

                if self.config.use_lr_decay == 1:
                    if count%self.config.lr_decay_step == 0:
                        self.scheduler.step()         
            else:
                print('jump one batch')     
                
            time_end=time.time()                
            
            def loss_record(loss_list,window):
                recent_list=loss_list[max(0,len(loss_list)-window*int(self.config.true_batch_size/self.config.batch_size)):]
                return str(np.mean(recent_list))[:4]
            
            if count % self.config.checkfreq == 0:       
                record=str(count)+' iter '+str(self.dataloader.epoch) +' epoch avg_loss:'+loss_record(loss_list,1000)
                    
                record+=' -- use time:'+str(time_end-time_start)[:5]
                print(record)
                
                
            if count % self.config.savefreq == 0 and count > self.config.savefreq-1000 and count > self.config.startfreq:     
                recent_loss=loss_list[max(0,len(loss_list)-1000*int(self.config.true_batch_size/self.config.batch_size)):]
                avg_loss=sum(recent_loss)/len(recent_loss)
                 
                print('start val')
                acc=self.do_val(500)  
                
                self.save_model(avg_loss,loss_list,acc,0,'') 
                self.generator.module.train()         
                
                
    def do_val(self, val_num):

        self.raw_rouge=Rouge()
        self.generator.module.eval()
        
        data_loader_val=data_loader('test', self.config, self.tokenizer,model='relevance_check')
     
        accuracy=[]
        
     
        # evaluation metrics for diversity
   
        for i in tqdm(range(val_num),desc='Validation'):     

            
            batch_source_id,batch_source_id_mask,batch_target_id,batch_target_id_mask,batch_label,batch_source,batch_target,batch_other_data = \
            data_loader_val.load_data()

            with torch.no_grad():      
                output=self.generator.module(input_ids=batch_source_id,
                                      attention_mask=batch_source_id_mask)
            predict=torch.argmax(output.logits, dim=1)  
            predict=predict.tolist()
            gold=batch_label.tolist()
            
            c=0
            for i in range(len(predict)):
                if gold[i]==predict[i]:
                    c+=1
            accuracy.append(c/len(predict))
    
            if data_loader_val.epoch>=2:
                break
   
                    
        if len(accuracy) != 0:
            return np.mean(accuracy)
        else:
            return 0            




        
        
def argLoader():

    parser = argparse.ArgumentParser()
    
    #device
    
    parser.add_argument('--device', type=int, default=0)    
    
    parser.add_argument('--multi_gpu', type=int, default=1)        

    parser.add_argument('--multi_device', type=str, default='0,1,2,3')       
    # Do What
    
    parser.add_argument('--do_train', action='store_true', help="Whether to run training")

    parser.add_argument('--do_test', action='store_true', help="Whether to run test")
    
    parser.add_argument('--data_path', type=str, default='') 
    
    parser.add_argument('--seed', type=int, default=10)  
    
    parser.add_argument('--data_augmentation', type=int, default=0)    
    
    
    
    parser.add_argument('--pretrained_model', type=str, default='hfl/chinese-roberta-wwm-ext')  
    
    parser.add_argument('--pretrained_tokenizer', type=str, default='hfl/chinese-roberta-wwm-ext')  

    parser.add_argument('--bos_token_id', type=int, default=0) 
    
    parser.add_argument('--pad_token_id', type=int, default=0) 
    
    parser.add_argument('--eos_token_id', type=int, default=1)
    #Preprocess Setting
    parser.add_argument('--max_summary', type=int, default=20)

    parser.add_argument('--max_article', type=int, default=300)    
    
    #Model Setting
    parser.add_argument('--hidden_dim', type=int, default=768)

    parser.add_argument('--emb_dim', type=int, default=768)
    
    parser.add_argument('--vocab_size', type=int, default=50264)      

    parser.add_argument('--lr', type=float, default=5e-5)     
    
    parser.add_argument('--eps', type=float, default=1e-10)
    
    parser.add_argument('--prefix_dropout', type=float, default=0)    
        
    parser.add_argument('--batch_size', type=int, default=128)  

    parser.add_argument('--true_batch_size', type=int, default=128)  

    parser.add_argument('--buffer_size', type=int, default=8192)      
    
    parser.add_argument('--scale_embedding', type=int, default=0)  
    
    #lr setting

    parser.add_argument('--use_lr_decay', type=int, default=0)  
    
    parser.add_argument('--lr_decay_step', type=int, default=10000)  
    
    parser.add_argument('--lr_decay', type=float, default=1)  

    # Testing setting
    parser.add_argument('--beam_size', type=int, default=2)
    
    parser.add_argument('--max_dec_steps', type=int, default=15)
    
    parser.add_argument('--min_dec_steps', type=int, default=2)
    
    parser.add_argument('--test_model', type=str, default='')   
    
    parser.add_argument('--load_model', type=str, default='')  

    parser.add_argument('--save_path', type=str, default='')  
    
    parser.add_argument('--mid_start', type=int, default=0)
   
    # Checkpoint Setting
    parser.add_argument('--max_epoch', type=int, default=40)
    
    parser.add_argument('--train_set_len', type=int, default=190000)
    
    parser.add_argument('--savefreq', type=int, default=1200)

    parser.add_argument('--checkfreq', type=int, default=1)    

    parser.add_argument('--startfreq', type=int, default=1)        
    
    args = parser.parse_args()
    
    return args





def main():
    args = argLoader()
    
    if args.multi_gpu==1:
        torch.cuda.set_device(args.device)
        os.environ['CUDA_VISIBLE_DEVICES'] = args.multi_device
    else:
        torch.cuda.set_device(args.device)

    print('CUDA', torch.cuda.current_device())
    
        
    if args.do_train == 1:
        x=Train(args)
        x.train_iter()



main()
        