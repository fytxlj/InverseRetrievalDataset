from rank_bm25 import BM25Okapi
from corpus_loader import *
import numpy as np
import time,copy
import argparse
import math
import torch
import torch.nn as nn
from rouge import Rouge
from torch.optim import *
from corpus_loader import QD_loader,ms_loader
import os 
from tqdm import tqdm
import jieba
from transformers import AutoTokenizer,AutoModelForSeq2SeqLM
import json

class bm25(object):
    
    
    def __init__(self, source, language=''):
        
        self.source=source
        
        self.language=language
        
        if self.language == 'e':
            tokenized_source = [doc.split(" ") for doc in source]       
        if self.language == 'c':
            tokenized_source = [list(jieba.cut(doc, cut_all=False)) for doc in source]                
        
        self.bm25 = BM25Okapi(tokenized_source)  
    
    def retrieve(self, query, num=1):
        
        if self.language == 'e':
            tokenized_query = query.split(" ")      
        if self.language == 'c':
            tokenized_query = list(jieba.cut(query, cut_all=False))
        
        return self.bm25.get_top_n(tokenized_query, self.source, n=num)        


def p_r(pred,gold):
    p=0
    r=0
    
    for j in gold:
        if j in pred:
            r+=1
    
    for j in pred:
        if j in gold:
            p+=1     
            
    p=p/len(pred)
    r=r/len(gold)
    
    return p,r

class bm25_base(object):

    def __init__(self, dataset):
        
        self.dataset=dataset
        
        
        if self.dataset == 'QD':
            
            self.language = 'c'
            
            self.dataloader = QD_loader('data/dataset_json/')
            
        if self.dataset == 'ms_marco':
            
            self.language = 'e'
            
            self.dataloader = ms_loader('data/ms/')
            
            
        
    def inference(self, k):
        
        queries, docs, query_to_doc = self.dataloader.load_data()
        
        bm25_model = bm25(docs, self.language)
        
        precision=[]
        recall=[]
        
        precision5=[]
        recall5=[]
        precision3=[]
        recall3=[]
        precision1=[]
        recall1=[]        
        
        time_one_query=[]
        
        result={}
        
        for i in tqdm(queries, desc='inference'):
            
            time_start=time.time()
        
            gold = query_to_doc[i]
            pred = bm25_model.retrieve(i, k)
            
            time_end=time.time()
            
            p,r = p_r(pred, gold)
            precision.append(p)
            recall.append(r)
            
            p5,r5 = p_r(pred[:5], gold)
            precision5.append(p5)
            recall5.append(r5)

            p3,r3 = p_r(pred[:3], gold)
            precision3.append(p3)
            recall3.append(r3)            
            
            p1,r1 = p_r(pred[:1], gold)
            precision1.append(p1)
            recall1.append(r1)     
            
            
            time_one_query.append(time_end-time_start)

            result[i]=pred[:5]
            
        precision=np.mean(precision)     
        recall=np.mean(recall)     
        time_one_query=np.mean(time_one_query)
        
        precision1=np.mean(precision1)     
        recall1=np.mean(recall1)  
        precision3=np.mean(precision3)     
        recall3=np.mean(recall3)  
        precision5=np.mean(precision5)     
        recall5=np.mean(recall5)          
        
        save_path='mid_data/result_'+self.dataset+'_bm25'

        with open(save_path, 'w', encoding='utf-8') as save:
            json.dump(result, save, sort_keys=True, ensure_ascii=False)
        
        return [precision, precision5, precision3, precision1], [recall,recall5,recall3,recall1], time_one_query
    
    
    

class bm25_doc2query(object):

    def __init__(self, dataset, model_path, query_path=''):
        
        self.dataset=dataset
        self.model_path=model_path
        self.query_path=query_path
        
        x=torch.load('save_model/'+self.model_path,map_location='cpu')
        self.model = x['generator']  
        self.model.cuda()
        
        
        if self.dataset == 'QD':
            
            self.language = 'c'
            
            self.dataloader = QD_loader('data/dataset_json/')
            
            self.tokenizer = AutoTokenizer.from_pretrained('doc2query/msmarco-chinese-mt5-base-v1')
            
        if self.dataset == 'ms_marco':
            
            self.language = 'e'
            
            self.dataloader = ms_loader('data/ms/')
            
            self.tokenizer = AutoTokenizer.from_pretrained('doc2query/msmarco-t5-base-v1')
            
        
    def inference(self, k, use_q_number=10):
        
        queries, docs, query_to_doc = self.dataloader.load_data()
        
        doc_num=len(docs)
        batch = 100
        
        
        if self.query_path=='':
            extend_queries=[]
            
            for i in tqdm(range(int(doc_num/batch)+1), desc='generate queries'):
                
                if i == int(doc_num/batch):
                    batch_doc = docs[i*batch:]                
                else:
                    batch_doc = docs[i*batch:(i+1)*batch]
                    
                extend_queries+=self.doc2query(batch_doc, use_q_number)
                    
            assert len(extend_queries) == len(docs), 'the doc2query final check fail, doc number != extend queries number'       
            
            
            with open('mid_data/bm25_doc2query_'+self.dataset+'__'+self.model_path, 'w', encoding='utf-8') as save:
                for i in extend_queries:
                    save.write(str(i)+'\n')
                
        else:
            with open(self.query_path, 'r', encoding='utf-8') as load:
                extend_queries=load.readlines()
            extend_queries=[x.strip('\n') for x in extend_queries]
            assert len(extend_queries) == len(docs), 'the doc2query final check fail, doc number != extend queries number'  
            
        
        
        docwquery_to_doc={}
        docwquery=[]
        for i in range(len(docs)):
            docwquery.append(extend_queries[i]+' '+docs[i])
            docwquery_to_doc[extend_queries[i]+' '+docs[i]]=docs[i]
            
            
        bm25_model = bm25(docwquery, self.language)
        precision=[]
        recall=[]
        
        precision5=[]
        recall5=[]
        precision3=[]
        recall3=[]
        precision1=[]
        recall1=[]        
        time_one_query=[]
        
        for i in tqdm(queries, desc='inference'):

            gold = query_to_doc[i]
            time_start=time.time()
            pred = bm25_model.retrieve(i, k)
            pred = [docwquery_to_doc[x] for x in pred]
            time_end=time.time()
            
            p,r = p_r(pred, gold)
            precision.append(p)
            recall.append(r)
            
            p5,r5 = p_r(pred[:5], gold)
            precision5.append(p5)
            recall5.append(r5)

            p3,r3 = p_r(pred[:3], gold)
            precision3.append(p3)
            recall3.append(r3)            
            
            p1,r1 = p_r(pred[:1], gold)
            precision1.append(p1)
            recall1.append(r1)        
                      
            time_one_query.append(time_end-time_start)
            
        precision=np.mean(precision)     
        recall=np.mean(recall)     
        time_one_query=np.mean(time_one_query)
        
        precision1=np.mean(precision1)     
        recall1=np.mean(recall1)  
        precision3=np.mean(precision3)     
        recall3=np.mean(recall3)  
        precision5=np.mean(precision5)     
        recall5=np.mean(recall5)          
        
        return [precision, precision5, precision3, precision1], [recall,recall5,recall3,recall1], time_one_query
    
    
    def doc2query(self, docs, use_q_number):
        
        batch_source_id=[]
        for i in docs:
            source_id=(self.tokenizer.encode(i))[:300]  
            batch_source_id.append(source_id)
            
        batch_source_id,batch_source_id_mask=self.pad_with_mask(batch_source_id, pad_id=0)
        batch_source_id=torch.tensor(batch_source_id).cuda()
        batch_source_id_mask=torch.tensor(batch_source_id_mask).cuda()
        
        with torch.no_grad():         
            outputs_beam = self.model.generate(input_ids=batch_source_id,
                                               attention_mask=batch_source_id_mask,
                                                max_length=12,
                                                do_sample=True,
                                                top_p=0.95,
                                                top_k=10, 
                                                temperature=2.0,
                                                no_repeat_ngram_size=2,
                                                num_return_sequences=use_q_number)       
            
        
        decoded_pred = self.tokenizer.batch_decode(outputs_beam, skip_special_tokens=True)  
        
        assert len(decoded_pred) == len(docs)*use_q_number, 'the doc2query fail, doc number*sample number != extend queries number'     
        
        decoded_pred_split=[]
        
        for i in range(len(docs)):
            decoded_pred_split.append(decoded_pred[i*use_q_number:(i+1)*use_q_number])
            
            #print(docs[i])
            #print(decoded_pred[i*10:(i+1)*10])
            
        decoded_pred_split = [' '.join(x) for x in decoded_pred_split]
        
        assert len(decoded_pred_split) == len(docs), 'the doc2query fail, doc number != extend queries number'       
        
        return decoded_pred_split
    
    
    def pad_with_mask(self, data, pad_id=0, width=-1):
        if (width == -1):
            width = max(len(d) for d in data)
            
        rtn_data = [d + [pad_id] * (width - len(d)) for d in data]
        
        pad_mask = [[1] * len(d) + [0] * (width - len(d)) for d in data]
        return rtn_data,pad_mask    
    
class bm25_bert(object):

    def __init__(self, dataset, model_path):
        
        self.dataset=dataset
        self.model_path=model_path
        
        x=torch.load('save_model/'+self.model_path,map_location='cpu')
        self.model = x['generator']  
        self.model.cuda()
        
        
        if self.dataset == 'QD':
            
            self.language = 'c'
            
            self.dataloader = QD_loader('data/dataset_json/')
            
            self.tokenizer = AutoTokenizer.from_pretrained('hfl/chinese-roberta-wwm-ext')
            
        if self.dataset == 'ms_marco':
            
            self.language = 'e'
            
            self.dataloader = ms_loader('data/ms/')
            
            self.tokenizer = AutoTokenizer.from_pretrained('textattack/bert-base-uncased-yelp-polarity')
            
            
        
    def inference(self, rerank_num, k):
        
        queries, docs, query_to_doc = self.dataloader.load_data()
        
        bm25_model = bm25(docs, self.language)
        
        precision=[]
        recall=[]
        
        precision5=[]
        recall5=[]
        precision3=[]
        recall3=[]
        precision1=[]
        recall1=[]        
        
        time_one_query=[]
        for i in tqdm(queries, desc='inference'):
            
            gold = query_to_doc[i]
            
            time_start=time.time()
            
            pred = bm25_model.retrieve(i, rerank_num)
            
            batch = 100
            pred_score=[]
            for j in range(int(rerank_num/batch)):
                
                batch_doc = pred[j*batch:(j+1)*batch]
            
                pred_score_batch = self.bert_relevance_check(i, batch_doc)
                pred_score+=pred_score_batch
            
            
            pred_with_score=[]
            for j in range(len(pred)):
                pred_with_score.append((pred[j],pred_score[j]))
            
            pred_with_score = sorted(pred_with_score, key=lambda x:x[1], reverse=True)
 
            
            pred=[x[0] for x in pred_with_score[:k]]
            
            time_end=time.time()
            
            p,r = p_r(pred, gold)
            precision.append(p)
            recall.append(r)
            
            p5,r5 = p_r(pred[:5], gold)
            precision5.append(p5)
            recall5.append(r5)

            p3,r3 = p_r(pred[:3], gold)
            precision3.append(p3)
            recall3.append(r3)            
            
            p1,r1 = p_r(pred[:1], gold)
            precision1.append(p1)
            recall1.append(r1)  
            
            
            time_one_query.append(time_end-time_start)
            
            
        precision=np.mean(precision)     
        recall=np.mean(recall)     
        time_one_query=np.mean(time_one_query)
        
        precision1=np.mean(precision1)     
        recall1=np.mean(recall1)  
        precision3=np.mean(precision3)     
        recall3=np.mean(recall3)  
        precision5=np.mean(precision5)     
        recall5=np.mean(recall5)          
        
        return [precision, precision5, precision3, precision1], [recall,recall5,recall3,recall1], time_one_query
            
    
    def bert_relevance_check(self, query, docs):            
        batch_source_id=[]
        for i in docs:
            source_id=(self.tokenizer.encode(query)+self.tokenizer.encode(i))[:300]  
            batch_source_id.append(source_id)
        
        
        batch_source_id,batch_source_id_mask=self.pad_with_mask(batch_source_id, pad_id=0)
        batch_source_id=torch.tensor(batch_source_id).cuda()
        batch_source_id_mask=torch.tensor(batch_source_id_mask).cuda()
        
        #print(batch_source_id.size(), batch_source_id_mask.size())

        with torch.no_grad():      
            output=self.model(input_ids=batch_source_id,
                                  attention_mask=batch_source_id_mask)

        predict=torch.softmax(output.logits, dim=1)  
        predict=predict.tolist()
        predict=[x[0] for x in predict]
        
        assert len(predict) == len(docs), 'the relevance prediction fail, doc number != relevance score number'
        
        return predict
        
        
        
        
    def pad_with_mask(self, data, pad_id=0, width=-1):
        if (width == -1):
            width = max(len(d) for d in data)
            
        rtn_data = [d + [pad_id] * (width - len(d)) for d in data]
        
        pad_mask = [[1] * len(d) + [0] * (width - len(d)) for d in data]
        return rtn_data,pad_mask         
    
    
    
    


class inverse_retrieval(object):

    def __init__(self, dataset, model_path, mutli_gpu='', query_path=''):
        
        self.dataset=dataset
        self.model_path=model_path
        self.query_path=query_path
        
        x=torch.load('save_model/'+self.model_path,map_location='cpu')
        self.model = x['generator']  
        self.model.cuda()
        
        
        if self.dataset == 'QD':
            
            self.language = 'c'
            
            self.dataloader = QD_loader('data/dataset_json/')
            
            self.tokenizer = AutoTokenizer.from_pretrained('doc2query/msmarco-chinese-mt5-base-v1')
            
        if self.dataset == 'ms_marco':
            
            self.language = 'e'
            
            self.dataloader = ms_loader('data/ms/')
            
            self.tokenizer = AutoTokenizer.from_pretrained('doc2query/msmarco-t5-base-v1')
            
        if mutli_gpu!='':
            gpus=[int(gpu) for gpu in mutli_gpu.split(',')]
            self.model = nn.DataParallel(self.model, device_ids=gpus, output_device=gpus[0])
            
        
    def inference(self, k, use_q_number = 10):
        
        queries, docs, query_to_doc = self.dataloader.load_data()
        
        doc_num=len(docs)
        batch = 2
        
        if self.query_path == '':
            extend_queries=[]
            
            for i in tqdm(range(int(doc_num/batch)+1), desc='generate queries'):
                
                if i == int(doc_num/batch):
                    batch_doc = docs[i*batch:]                
                else:
                    batch_doc = docs[i*batch:(i+1)*batch]
                    
                extend_queries+=self.doc2query(batch_doc)
                    
            assert len(extend_queries) == len(docs), 'the doc2query final check fail, doc number != extend queries number'   
            
            with open('mid_data/bm25_ir_'+self.dataset+'__'+self.model_path, 'w', encoding='utf-8') as save:
                for i in extend_queries:
                    save.write(str(i)+'\n')
        else:
            with open(self.query_path, 'r', encoding='utf-8') as load:
                extend_queries=load.readlines()
                extend_queries=[eval(x.strip('\n')) for x in extend_queries]
            assert len(extend_queries) == len(docs), 'the doc2query final check fail, doc number != extend queries number'              
        
        query_to_doc_pred={}
        for i in range(len(docs)):
            doc = docs[i]
            q_list=extend_queries[i]
            for q in q_list:
                if q in query_to_doc_pred.keys():
                    query_to_doc_pred[q]+=[doc]
                else:
                    query_to_doc_pred[q]=[doc]
                    
                    
        docwquery_to_doc={}
        docwquery=[]
        for i in range(len(docs)):
            docwquery.append(' '.join(extend_queries[i][:use_q_number])+' '+docs[i])
            docwquery_to_doc[' '.join(extend_queries[i][:use_q_number])+' '+docs[i]]=docs[i]
            
        bm25_model = bm25(docwquery, self.language)

        precision=[]
        recall=[]
        
        precision5=[]
        recall5=[]
        precision3=[]
        recall3=[]
        precision1=[]
        recall1=[]        
        
        c3=0
        c5=0
        c10=0
        
        
        time_one_query=[]
        
        len_pred=[]
        
        result={}
        
        for i in tqdm(queries, desc='inference'):
            gold = query_to_doc[i]
            
            
            time_start=time.time()
            
            pred_bm25 = bm25_model.retrieve(i, k*3)
            pred_bm25 = [docwquery_to_doc[x] for x in pred_bm25]
            

            if i in query_to_doc_pred.keys():
                pred=query_to_doc_pred[i][:10]
            else:
                pred=[]
                
            len_pred.append(len(pred))
            
            if len(pred) >=3:
                c3+=1
            if len(pred) >=5:
                c5+=1
            if len(pred) >=10:
                c10+=1                
            
            #pred=pred+pred_bm25[:k-len(pred)]
            
            for p in pred_bm25:
                if len(pred) == k:
                    break
                if p not in pred:
                    pred.append(p)

            
            assert len(pred) == k, 'pred doc is not equal to k'
            
            
                
            time_end=time.time()
            
            p,r = p_r(pred, gold)
            precision.append(p)
            recall.append(r)
            
            p5,r5 = p_r(pred[:5], gold)
            precision5.append(p5)
            recall5.append(r5)

            p3,r3 = p_r(pred[:3], gold)
            precision3.append(p3)
            recall3.append(r3)            
            
            p1,r1 = p_r(pred[:1], gold)
            precision1.append(p1)
            recall1.append(r1)  
            
            
            time_one_query.append(time_end-time_start)
            
            result[i]=pred[:5]
            
        len_pred=np.mean(len_pred)
        
        precision=np.mean(precision)     
        recall=np.mean(recall)     
        time_one_query=np.mean(time_one_query)
        
        precision1=np.mean(precision1)     
        recall1=np.mean(recall1)  
        precision3=np.mean(precision3)     
        recall3=np.mean(recall3)  
        precision5=np.mean(precision5)     
        recall5=np.mean(recall5)       
        
        save_path='mid_data/result_'+self.dataset+'_ir'

        with open(save_path, 'w', encoding='utf-8') as save:
            json.dump(result, save, sort_keys=True, ensure_ascii=False)
        
        print('count effective doc', c3, c5, c10)
        return [precision, precision5, precision3, precision1], [recall,recall5,recall3,recall1], time_one_query, len_pred
    
    def doc2query(self, docs):
        
        batch_source_id=[]
        for i in docs:
            source_id=(self.tokenizer.encode(i))[:300]  
            batch_source_id.append(source_id)
            
        batch_source_id,batch_source_id_mask=self.pad_with_mask(batch_source_id, pad_id=0)
        batch_source_id=torch.tensor(batch_source_id).cuda()
        batch_source_id_mask=torch.tensor(batch_source_id_mask).cuda()
        
        with torch.no_grad():         
            outputs_beam = self.model.generate(input_ids=batch_source_id,
                                               attention_mask=batch_source_id_mask,
                                                max_length=12,
                                                do_sample=True,
                                                top_p=0.95,
                                                top_k=12, 
                                                temperature=2.0,
                                                no_repeat_ngram_size=2,
                                                num_return_sequences=400)       
            
        
        decoded_pred = self.tokenizer.batch_decode(outputs_beam, skip_special_tokens=True)  
        
        assert len(decoded_pred) == len(docs)*400, 'the doc2query fail, doc number*sample number != extend queries number'     
        
        decoded_pred_split=[]
        
        for i in range(len(docs)):
            decoded_pred_split.append(list(set(decoded_pred[i*400:(i+1)*400])))
            
            #print(docs[i])
            #print(decoded_pred[i*200:(i+1)*200])
            #print('-------------------------')
        
        assert len(decoded_pred_split) == len(docs), 'the doc2query fail, doc number != extend queries number'       
        
        return decoded_pred_split
    
    
    def pad_with_mask(self, data, pad_id=0, width=-1):
        if (width == -1):
            width = max(len(d) for d in data)
            
        rtn_data = [d + [pad_id] * (width - len(d)) for d in data]
        
        pad_mask = [[1] * len(d) + [0] * (width - len(d)) for d in data]
        return rtn_data,pad_mask        
    
    
    
    
    







def argLoader():

    parser = argparse.ArgumentParser()
    
    #device
    
    parser.add_argument('--device', type=int, default=5)    
    
    parser.add_argument('--multi_gpu', type=int, default=0)   
    
    parser.add_argument('--gpus', type=str, default='')   
    
    parser.add_argument('--module', type=str, default='base')          
    
    args = parser.parse_args()
    
    return args    
    
    
args = argLoader()


if args.multi_gpu==1:
    torch.cuda.set_device(args.device)
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpus
else:
    torch.cuda.set_device(args.device)


if args.module == 'base':

    base_QD=bm25_base('QD')
    
    p,r,t = base_QD.inference(10)
    
    print('QD on bm25_base, p&r:',p,r,t)
    
    base_ms=bm25_base('ms_marco')
    
    p,r,t = base_ms.inference(10)
    
    print('ms on bm25_base, p&r:',p,r,t)


if args.module == 'bert':

    QD_rele_model=''
    ms_rele_model=''
    
    base_QD=bm25_bert('QD', QD_rele_model)
    
    p,r,t = base_QD.inference(100,10)
    
    print('QD on bm25_bert, p&r:',p,r,t)
    
    base_ms=bm25_bert('ms_marco', ms_rele_model)
    
    p,r,t = base_ms.inference(100,10)
    
    print('ms on bm25_bert, p&r:',p,r,t)

if args.module == 'doc2query':

    QD_doc2query_model=''
    ms_doc2query_model=''
    
    
    doc2query_QD=bm25_doc2query('QD', QD_doc2query_model)
    
    p,r,t = doc2query_QD.inference(10)
    
    print('QD on bm25_doc2query, p&r:',p,r,t)
    
    doc2query_ms=bm25_doc2query('ms_marco', ms_doc2query_model)
    
    p,r,t = doc2query_ms.inference(10)
    
    print('ms on bm25_doc2query, p&r:',p,r,t)
    

if args.module == 'ir':

    QD_doc2query_model=''
    ms_doc2query_model=''
    
    
    doc2query_QD=inverse_retrieval('QD', QD_doc2query_model,args.gpus)
    
    p,r,t,l = doc2query_QD.inference(10)
    
    print('QD on bm25_ir, p&r:',p,r,t,l)
    
    doc2query_ms=inverse_retrieval('ms_marco', ms_doc2query_model,args.gpus)
    
    p,r,t,l = doc2query_ms.inference(10)
    
    print('ms on bm25_ir, p&r:',p,r,t,l)
    
