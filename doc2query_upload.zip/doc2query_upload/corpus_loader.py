import glob
import json


class QD_loader():

    def __init__(self,data_path):

        super(QD_loader,self).__init__()  

 
        self.source_path = data_path
        
        self.source_path+='test*'   

       
    def load_multiple_json(self, path):
        path_list=glob.glob(path)
        data_all=[]
        for i in path_list:
            with open(i,'r') as load_f:
                data = json.load(load_f)  
                data_all+=data.values()
        return data_all


    def load_data(self):

        data = self.load_multiple_json(self.source_path)                   
            
        print('the data number for one epoch is ', len(data))
        
        queries=[]
        docs=[]
        query2doc={}
        
            
        for data_point in data:
            
            doc=data_point["doc"]
            
            reference_query_high_rele=data_point["query_high_rele"]
            
            queries+=reference_query_high_rele
            docs.append(doc)
            
            for q in reference_query_high_rele:
                if q in query2doc.keys():
                    if doc not in query2doc[q]:
                        query2doc[q]+=[doc]
                else:
                    query2doc[q]=[doc]
                
                
        return queries,docs,query2doc


class ms_loader():

    def __init__(self,data_path):

        super(ms_loader,self).__init__()  

 
        self.source_path = data_path
        
        self.source_path+='dev_v1.1.json'

      

       
    def load_json(self, path):
        with open(path,'r',encoding="utf8") as load_f:
            data = load_f.readlines() 
        return [eval(x) for x in data]

                
                
    def load_data(self):

        data = self.load_json(self.source_path)                   
            
        print('the data number for one epoch is ', len(data))
        
        queries=[]
        docs=[]
        query2doc={}
        
            
        for data_point in data:
            

            pos_doc=[]
            neg_doc=[]
            
            for p in data_point['passages']:
                if p['is_selected'] == 1:
                    pos_doc.append(p['passage_text'])
                else:
                    neg_doc.append(p['passage_text']) 
                    
            reference_query_high_rele=data_point['query']
            
            
            if len(pos_doc) == 0:
                continue
            
            queries.append(reference_query_high_rele)
            docs+=pos_doc
            docs+=neg_doc
            

            if reference_query_high_rele in query2doc.keys():
                query2doc[reference_query_high_rele]+=[pos_doc[0]]
            else:
                query2doc[reference_query_high_rele]=[pos_doc[0]]
                
                
        return queries,docs,query2doc
